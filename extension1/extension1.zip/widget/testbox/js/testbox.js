window.onload = function (){

	document.getElementById("teste").innerHTML = "teste";
}
